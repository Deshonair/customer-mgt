from typing import Text
from sqlalchemy.schema import Column
from sqlalchemy.types import String, Integer, Text
from database import Base


class Customer(Base):
    __tablename__ = "Customer"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(20))
    account_number = Column(String(20), unique=True)
    request_type = Column(String(20))
    request_desc = Column(Text())