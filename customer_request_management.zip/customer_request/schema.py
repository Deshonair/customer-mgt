from datetime import date
from pydantic import BaseModel

class Customer(BaseModel):
    id = int
    name = str
    account_number = str
    request_type = str
    request_desc = str
    date = date

    class Config:
        orm_mode = True